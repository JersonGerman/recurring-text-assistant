document.addEventListener('DOMContentLoaded', function () {
    const textEntriesContainer = document.getElementById('textEntries');
    const copyButton = document.getElementById('copyButton');

    copyButton.addEventListener('click', function () {
        const textEntries = textEntriesContainer.querySelectorAll('.text-entry');
        let combinedText = '';

        textEntries.forEach(function (entry) {
            combinedText += entry.textContent.trim() + '\n';
        });

        // Copiar el texto combinado al portapapeles
        navigator.clipboard.writeText(combinedText)
            .then(() => {
                alert('Texto copiado al portapapeles.');
            })
            .catch(err => {
                console.error('Error al copiar texto:', err);
            });
    });

    // Función para agregar una nueva fila de texto
    function addTextEntry() {
        const textEntry = document.createElement('div');
        textEntry.classList.add('text-entry');

        const input = document.createElement('input');
        input.type = 'text';
        input.placeholder = 'Introduce tu texto aquí';

        textEntry.appendChild(input);
        textEntriesContainer.appendChild(textEntry);
    }

    // Agregar una fila de texto inicial
    addTextEntry();
});
